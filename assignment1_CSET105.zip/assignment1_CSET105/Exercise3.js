//When comparing words it compares each letter one by one and if they share the same the same letter value for the 1st it'll go on to the lext letter than compare.
//example: Apple and apple will look at the 'A' to the 'a' and because 'a' is "greater/ higher index" it'll make apple the greater word 

console.log("Apple" > "Orange");//false
//false
console.log("Apple" > "apple");//false
//false
console.log("Apple" > "aPPLE");//false
//false
console.log("ABCD" == "ABCD");//true
//true
console.log("abcd" === "dcba");//false
//false
console.log("2" == 2);//true
//true
console.log("2" === 2 );//false
//false
console.log("12" == 21);//false
//false
console.log("Two" == 2);//false
//false
console.log(null == null);//true
//true
console.log(null == undefined);//inccorrect: false
//true