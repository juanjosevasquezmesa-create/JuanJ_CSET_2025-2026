console.log(`125 divided by pi is ${125/Math.PI}\n`); //

console.log(`The current world population is about 7000000000\n
    Lets say 7.139% of them are finacially stable\n
    That makes 7e9 * 7.139 / 100 = ${7e9 * 7.139 / 100}\n 
    if ${7e9 * 7.139 / 100} people each donate \$0.01 a day,\n 
    imagine how much money we can collect!\n
    ${7e9 * 7.139 / 100} * 0.01 woule be ${7e9 * 7.139 / 100 * 0.01} dollars a day!\n
    Which is ${7e9 * 7.139 / 100 * 0.01 *365} dollars a year!`);