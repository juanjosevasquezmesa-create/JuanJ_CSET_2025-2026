let btnArray = document.getElementsByClassName("btn"); //Array

let initialBtnColorArray = [];

for (let i = 0; i < btnArray.length; i++) {//to give initial colors to the buttons and store them
    initialBtnColorArray[i] = generateRandomRgbColor();
    btnArray[i].setAttribute("style", `background-color: ${initialBtnColorArray[i]}; border-radius: 5px`);
    
}

let choiceObj = {
    "red": () => {
        for (let i = 0; i < btnArray.length; i++) {
            btnArray[i].style.backgroundColor = "red";
        }
        
    },
    "green": () => {
        for (let i = 0; i < btnArray.length; i++) {
            btnArray[i].style.backgroundColor = "green";
        }
        
    },
    "blue": () => {
        for (let i = 0; i < btnArray.length; i++) {
            btnArray[i].style.backgroundColor = "blue";
        }
        
    },
    "random": () => {
        for (let i = 0; i < btnArray.length; i++) {
            btnArray[i].style.backgroundColor = generateRandomRgbColor();
        }
        
    },
    "reset": () => {
        for (let i = 0; i < btnArray.length; i++) {
            btnArray[i].style.backgroundColor = initialBtnColorArray[i];
        }
        
    }
}


function clicked() {
    //these are in here becuase each tim the user clicks the button I want to track if they've changed their option becuase outsideo of this the val is always red (default)
    let optionChoice = document.getElementsByTagName("select")[0];
    //idk why but i can't get the value from the id of the select tag

    let val = optionChoice.value;

    console.log(val);
    
    choiceObj[val]();
}

//functions for the color creation
function generateRandomRgbColor() {
    const r = Math.floor(Math.random() * 256);
    const g = Math.floor(Math.random() * 256);
    const b = Math.floor(Math.random() * 256);
    return `rgb(${r}, ${g}, ${b})`;
}