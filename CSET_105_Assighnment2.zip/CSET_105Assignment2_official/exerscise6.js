console.log("3's multiplication table upto 10 times: ")
for (let i = 1; i <= 10; i++) {
    console.log(`3 * ${i} = ${3*i}`);
    
}

console.log("17's multiplication table upto 10 times: ")
for (let i = 1; i <= 10; i++) {
    console.log(`17 * ${i} = ${17*i}`);
    
}
