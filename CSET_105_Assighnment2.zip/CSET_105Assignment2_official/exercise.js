let star = "#";

for (let i = 0; star.length <= 7 ; i++) {
    console.log(star);
    star = star + "#";
}