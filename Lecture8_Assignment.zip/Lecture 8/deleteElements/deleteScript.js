var myObj = document.getElementById("demo");
myObj.remove(); //this will remove the element